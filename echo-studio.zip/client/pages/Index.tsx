import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Separator } from '../components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Plus, Edit, Star, Calendar, Users, Music } from 'lucide-react';

interface Member {
  id: string;
  name: string;
  koreanName: string;
  birthDate: string;
  birthPlace: string;
  position: string[];
  nationality: string;
  avatar?: string;
  status: 'active' | 'solo' | 'hiatus' | 'former';
  leftYear?: number;

  // Physical details
  height: string;
  weight: string;
  bloodType: string;

  // Career details
  traineeYears: string;
  debutDate: string;
  subUnits: string[];
  soloDebut?: string;

  // Personal details
  education: string[];
  languages: string[];
  instruments: string[];
  hobbies: string[];
  nicknames: string[];

  // Professional details
  actingCareer: string[];
  modelingCareer: string[];
  soloAlbums: string[];
  awards: string[];

  // Social & Fun facts
  socialMedia: {
    instagram?: string;
    weibo?: string;
    other?: string;
  };
  representativeColor?: string;
  funFacts: string[];
  family: string[];
}

const initialMembers: Member[] = [
  {
    id: '1',
    name: 'Suho',
    koreanName: '수호',
    birthDate: '1991-05-22',
    birthPlace: 'Seoul, South Korea',
    position: ['Leader', 'Main Vocalist'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2Fdd2f23bd19fe426f9f7974a48291735b?format=webp&width=800',

    height: '173 cm',
    weight: '61 kg',
    bloodType: 'AB',
    traineeYears: '2006-2012 (7 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K'],
    soloDebut: '2020-03-30',
    education: ['Whimoon High School', 'Korea National University of Arts (Theater)'],
    languages: ['Korean', 'Japanese', 'Mandarin'],
    instruments: ['Piano'],
    hobbies: ['Golf', 'Reading', 'Watching movies'],
    nicknames: ['Guardian Angel', 'Bunny Leader', 'Rich Kid'],
    actingCareer: ['One Way Trip (2016)', 'The Universe\'s Star (2017)', 'Rich Man (2018)', 'Middle School Girl A (2018)', 'How to Buy a Friend (2020)'],
    modelingCareer: ['Various fashion magazines', 'Brand endorsements'],
    soloAlbums: ['Self-Portrait (2020)', 'Grey Suit (2022)'],
    awards: ['Various EXO group awards', 'Solo music awards'],
    socialMedia: {
      instagram: '@kimjuncotton'
    },
    representativeColor: 'Pearl Aqua',
    funFacts: [
      'Known for his leadership skills and caring nature',
      'Often called the "mom" of EXO',
      'Has a wealthy family background',
      'Excellent at golf',
      'Very organized and responsible'
    ],
    family: ['Parents', 'One younger brother']
  },
  {
    id: '2',
    name: 'Xiumin',
    koreanName: '시우민',
    birthDate: '1990-03-26',
    birthPlace: 'Guri, Gyeonggi Province, South Korea',
    position: ['Vocalist', 'Dancer'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2F62c128882d874f7398abc171822f87d0?format=webp&width=800',

    height: '173 cm',
    weight: '60 kg',
    bloodType: 'B',
    traineeYears: '2008-2012 (4 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M', 'EXO-CBX'],
    soloDebut: '2022-09-26',
    education: ['Guri Middle School', 'Guri High School', 'Catholic University of Korea (Applied Music)'],
    languages: ['Korean', 'Mandarin', 'Japanese'],
    instruments: ['Piano', 'Guitar'],
    hobbies: ['Taekwondo', 'Football', 'Cleaning'],
    nicknames: ['Eldest Hyung', 'Minseok', 'Fairy', 'Vampire'],
    actingCareer: ['Falling for Challenge (2015)', 'Kim Byung Man\'s Law of the Jungle (2016)', 'Seondal: The Man Who Sells the River (2016)', 'President (2017)', 'Dear My Room (2018)'],
    modelingCareer: ['Various endorsements', 'Fashion shows'],
    soloAlbums: ['Brand New (2022)'],
    awards: ['Various EXO group awards', 'Acting awards'],
    socialMedia: {
      instagram: '@e_xiu_o'
    },
    representativeColor: 'Frost',
    funFacts: [
      'Oldest member of EXO',
      'Known for his unchanging appearance (vampire jokes)',
      'Black belt in Taekwondo',
      'Very neat and clean',
      'Has a cute, childlike personality despite being the eldest'
    ],
    family: ['Parents', 'One younger sister']
  },
  {
    id: '3',
    name: 'Lay',
    koreanName: '레이',
    birthDate: '1991-10-07',
    birthPlace: 'Changsha, Hunan, China',
    position: ['Main Dancer', 'Vocalist', 'Rapper'],
    nationality: 'Chinese',
    status: 'solo',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2Fb876b99b61034ac990da199ddf718c61?format=webp&width=800',

    height: '177 cm',
    weight: '60 kg',
    bloodType: 'A',
    traineeYears: '2008-2012 (4 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M'],
    soloDebut: '2016-10-28',
    education: ['Hunan Normal University High School', 'Beijing Contemporary Music Academy'],
    languages: ['Mandarin', 'Korean', 'English'],
    instruments: ['Piano', 'Guitar'],
    hobbies: ['Dancing', 'Composing music', 'Acting'],
    nicknames: ['Unicorn', 'Little Star', 'Yixing'],
    actingCareer: ['To Be a Better Man (2016)', 'The Mystic Nine (2016)', 'Operation Love (2017)', 'The Island (2018)', 'Kung Fu Yoga (2017)'],
    modelingCareer: ['Numerous Chinese brand endorsements', 'International campaigns'],
    soloAlbums: ['Lose Control (2016)', 'Sheep (2017)', 'Namanana (2018)', 'Honey (2019)', 'Lit (2020)', 'Producer (2021)', 'Step (2022)'],
    awards: ['Numerous solo music awards', 'Acting awards', 'EXO group awards'],
    socialMedia: {
      weibo: '@努力努力再努力x',
      instagram: '@layzhang'
    },
    representativeColor: 'White',
    funFacts: [
      'Multi-talented artist and producer',
      'Founded his own company, Chromosome Entertainment',
      'Known for his healing smile',
      'Focuses primarily on Chinese market',
      'Expert in traditional Chinese culture'
    ],
    family: ['Parents', 'One younger sister']
  },
  {
    id: '4',
    name: 'Baekhyun',
    koreanName: '백현',
    birthDate: '1992-05-06',
    birthPlace: 'Bucheon, Gyeonggi Province, South Korea',
    position: ['Main Vocalist'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2F05238fc323534aa1b64eeea1b9195084?format=webp&width=800',

    height: '174 cm',
    weight: '64 kg',
    bloodType: 'O',
    traineeYears: '2011-2012 (1 year)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K', 'EXO-CBX', 'SuperM'],
    soloDebut: '2019-07-10',
    education: ['Jungwon High School', 'Kyung Hee Cyber University (Postmodern Music)'],
    languages: ['Korean', 'Japanese', 'Mandarin'],
    instruments: ['Piano'],
    hobbies: ['Gaming', 'Singing', 'Hapkido'],
    nicknames: ['Bacon', 'Genius Idol', 'Byun Baekhyun'],
    actingCareer: ['Moon Lovers: Scarlet Heart Ryeo (2016)', 'EXO Next Door (2015)'],
    modelingCareer: ['Lotte Duty Free', 'Various brand endorsements'],
    soloAlbums: ['City Lights (2019)', 'Delight (2020)', 'Bambi (2021)'],
    awards: ['Numerous solo and group awards', 'Vocal awards'],
    socialMedia: {
      instagram: '@baekhyunee_exo'
    },
    representativeColor: 'Light',
    funFacts: [
      'Known for his powerful vocals and stage presence',
      'Gaming enthusiast',
      'Has a very playful personality',
      'Member of SuperM',
      'Excellent variety show skills'
    ],
    family: ['Parents', 'One older brother']
  },
  {
    id: '5',
    name: 'Chen',
    koreanName: '첸',
    birthDate: '1992-09-21',
    birthPlace: 'Siheung, Gyeonggi Province, South Korea',
    position: ['Main Vocalist'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2F40e7f4a20d56487898021a2b046cabde?format=webp&width=800',

    height: '173 cm',
    weight: '65 kg',
    bloodType: 'B',
    traineeYears: '2011-2012 (1 year)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M', 'EXO-CBX'],
    soloDebut: '2019-04-01',
    education: ['Hanyang University (Applied Music)'],
    languages: ['Korean', 'Mandarin', 'Japanese'],
    instruments: ['Piano', 'Guitar', 'Drums'],
    hobbies: ['Singing', 'Playing instruments', 'Baseball'],
    nicknames: ['Dinosaur', 'Jongdae', 'Chen Chen'],
    actingCareer: ['EXO Next Door (2015)', 'Missing 9 (2017)'],
    modelingCareer: ['Various endorsements'],
    soloAlbums: ['April, and a flower (2019)', 'Dear my dear (2019)', 'Last Scene (2020)', 'Hello (2022)'],
    awards: ['Solo music awards', 'EXO group awards', 'OST awards'],
    socialMedia: {
      instagram: '@jongdae0921'
    },
    representativeColor: 'Lightning',
    funFacts: [
      'Known for his incredible vocal range',
      'Married with children',
      'Loves baseball',
      'Has a great sense of humor',
      'Often called the mood maker'
    ],
    family: ['Parents', 'Wife', 'Two daughters']
  },
  {
    id: '6',
    name: 'Chanyeol',
    koreanName: '찬열',
    birthDate: '1992-11-27',
    birthPlace: 'Seoul, South Korea',
    position: ['Main Rapper', 'Vocalist', 'Visual'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2Fd0311aaa32114e4a8d31f08a707519b6?format=webp&width=800',

    height: '185 cm',
    weight: '70 kg',
    bloodType: 'A',
    traineeYears: '2008-2012 (4 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K'],
    education: ['Hyundai High School', 'Inha University (Applied Music)'],
    languages: ['Korean', 'Japanese', 'English'],
    instruments: ['Guitar', 'Piano', 'Drums', 'Bass'],
    hobbies: ['Music production', 'Playing instruments', 'Photography'],
    nicknames: ['Happy Virus', 'Yeollie', 'King of Reactions'],
    actingCareer: ['EXO Next Door (2015)', 'Salut d\'Amour (2015)', 'So I Married an Anti-Fan (2016)', 'The Box (2021)'],
    modelingCareer: ['Tommy Hilfiger', 'Various brand endorsements'],
    soloAlbums: ['Various solo songs and collaborations'],
    awards: ['EXO group awards', 'Acting awards'],
    socialMedia: {
      instagram: '@real__pcy'
    },
    representativeColor: 'Fire',
    funFacts: [
      'Tallest member of EXO',
      'Multi-instrumentalist and producer',
      'Known for his bright and cheerful personality',
      'Excellent at variety shows',
      'Photography enthusiast'
    ],
    family: ['Parents', 'One younger sister (Park Yura - announcer)']
  },
  {
    id: '7',
    name: 'D.O.',
    koreanName: '디오',
    birthDate: '1993-01-12',
    birthPlace: 'Goyang, Gyeonggi Province, South Korea',
    position: ['Main Vocalist', 'Actor'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2Fa1c90fc7723b45e8be601f4cfbc66556?format=webp&width=800',

    height: '173 cm',
    weight: '65 kg',
    bloodType: 'A',
    traineeYears: '2010-2012 (2 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K'],
    soloDebut: '2021-07-26',
    education: ['Baekseok High School', 'Kyungsung University (Applied Music)'],
    languages: ['Korean', 'Japanese'],
    instruments: ['Piano'],
    hobbies: ['Cooking', 'Acting', 'Singing'],
    nicknames: ['Satansoo', 'Umma', 'Do Kyungsoo'],
    actingCareer: ['It\'s Okay, That\'s Love (2014)', 'Cart (2014)', 'My Annoying Brother (2016)', 'Positive Physique (2016)', 'Room No.7 (2017)', 'Along with the Gods (2017)', 'Swing Kids (2018)', 'The Moon (2023)'],
    modelingCareer: ['Various endorsements'],
    soloAlbums: ['Empathy (2021)', 'Expectation (2023)'],
    awards: ['Numerous acting awards', 'Solo music awards', 'EXO group awards'],
    socialMedia: {},
    representativeColor: 'Earth',
    funFacts: [
      'Renowned actor with multiple film awards',
      'Excellent cook',
      'Known for his serious personality but cute reactions',
      'Has a very soulful voice',
      'Prefers privacy and doesn\'t use social media much'
    ],
    family: ['Parents', 'One older brother']
  },
  {
    id: '8',
    name: 'Kai',
    koreanName: '카이',
    birthDate: '1994-01-14',
    birthPlace: 'Suncheon, Jeollanam-do, South Korea',
    position: ['Main Dancer', 'Vocalist', 'Center'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2Fa3c7ae3e6be14ee1b52b799ca49ac18e?format=webp&width=800',

    height: '182 cm',
    weight: '67 kg',
    bloodType: 'A',
    traineeYears: '2007-2012 (5 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K', 'SuperM'],
    soloDebut: '2020-11-30',
    education: ['Seoul School of Performing Arts'],
    languages: ['Korean', 'Japanese', 'English'],
    instruments: ['Piano'],
    hobbies: ['Dancing', 'Fashion', 'Playing with dogs'],
    nicknames: ['Nini', 'Dancing Machine', 'Kim Jongin'],
    actingCareer: ['Choco Bank (2016)', 'Andante (2017)', 'Spring Has Come (2018)'],
    modelingCareer: ['Gucci Ambassador', 'Various high-fashion brands'],
    soloAlbums: ['KAI (2020)', 'Peaches (2021)', 'Rover (2023)'],
    awards: ['Solo music awards', 'Dancing awards', 'EXO group awards', 'Fashion awards'],
    socialMedia: {
      instagram: '@zkdlin'
    },
    representativeColor: 'Teleportation',
    funFacts: [
      'Considered one of the best dancers in K-pop',
      'Gucci global ambassador',
      'Has three dogs (Monggu, Jjanggu, Jjangah)',
      'Known for his incredible stage presence',
      'Member of SuperM'
    ],
    family: ['Parents', 'Two older sisters']
  },
  {
    id: '9',
    name: 'Sehun',
    koreanName: '세훈',
    birthDate: '1994-04-12',
    birthPlace: 'Seoul, South Korea',
    position: ['Lead Dancer', 'Vocalist', 'Visual'],
    nationality: 'South Korean',
    status: 'active',
    avatar: 'https://cdn.builder.io/api/v1/image/assets%2F0b3f5f3701384e4bb37bfc3c0b7ef32e%2F4b9c5bc2fc6a4393b7ab7a86a3dcf550?format=webp&width=800',

    height: '183 cm',
    weight: '66 kg',
    bloodType: 'O',
    traineeYears: '2008-2012 (4 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-K'],
    education: ['Seoul School of Performing Arts'],
    languages: ['Korean', 'Mandarin'],
    instruments: ['Piano'],
    hobbies: ['Fashion', 'Baseball', 'Bubble tea'],
    nicknames: ['Maknae', 'Visual', 'Oh Sehun'],
    actingCareer: ['EXO Next Door (2015)', 'Dear Archimedes (2019)', 'Now We Are Breaking Up (2021)'],
    modelingCareer: ['Dior Ambassador', 'Various luxury brands'],
    soloAlbums: ['On Me (2023)'],
    awards: ['EXO group awards', 'Fashion awards'],
    socialMedia: {
      instagram: '@oohsehun'
    },
    representativeColor: 'Wind',
    funFacts: [
      'Youngest member of EXO',
      'Known for his model-like visuals',
      'Loves bubble tea',
      'Has a close friendship with many idols',
      'Very fashionable and style-conscious'
    ],
    family: ['Parents', 'One older brother']
  },
  {
    id: '10',
    name: 'Kris',
    koreanName: '크리스',
    birthDate: '1990-11-06',
    birthPlace: 'Guangzhou, China',
    position: ['Leader (EXO-M)', 'Main Rapper', 'Vocalist'],
    nationality: 'Chinese-Canadian',
    status: 'former',
    leftYear: 2014,

    height: '187 cm',
    weight: '74 kg',
    bloodType: 'O',
    traineeYears: '2008-2012 (4 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M'],
    soloDebut: '2016',
    education: ['Guangzhou No.7 Middle School', 'Sir Winston Churchill Secondary School (Canada)'],
    languages: ['Mandarin', 'English', 'Cantonese', 'Korean'],
    instruments: ['Basketball (sport)'],
    hobbies: ['Basketball', 'Acting', 'Fashion'],
    nicknames: ['Galaxy Fanfan', 'Wu Yifan', 'Kevin'],
    actingCareer: ['Somewhere Only We Know (2015)', 'Mr. Six (2015)', 'Sweet Sixteen (2016)', 'Journey to the West (2017)', 'L.O.R.D (2016)', 'Valerian (2017)'],
    modelingCareer: ['Louis Vuitton', 'Burberry', 'Various luxury brands'],
    soloAlbums: ['Antares (2016)', 'July (2017)', 'Like That (2018)', 'Big Bowl Thick Noodles (2020)'],
    awards: ['Acting awards in China', 'Music awards'],
    socialMedia: {
      weibo: '@吴亦凡',
      instagram: '@kriswu'
    },
    representativeColor: 'Dragon Power',
    funFacts: [
      'Tallest former member of EXO',
      'Moved to Canada at age 10',
      'Became a successful actor and rapper in China',
      'Known for his cold charisma',
      'Had legal disputes after leaving SM Entertainment'
    ],
    family: ['Mother', 'Stepfather']
  },
  {
    id: '11',
    name: 'Luhan',
    koreanName: '루한',
    birthDate: '1990-04-20',
    birthPlace: 'Haidian District, Beijing, China',
    position: ['Lead Vocalist', 'Lead Dancer', 'Visual'],
    nationality: 'Chinese',
    status: 'former',
    leftYear: 2014,

    height: '178 cm',
    weight: '60 kg',
    bloodType: 'O',
    traineeYears: '2010-2012 (2 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M'],
    soloDebut: '2014',
    education: ['Beijing Shida High School', 'Yonsei University (Applied Music) - did not complete'],
    languages: ['Mandarin', 'Korean', 'English'],
    instruments: ['Piano'],
    hobbies: ['Football', 'Video games', 'Music'],
    nicknames: ['Little Deer', 'Lu Xiaolu', 'Marilyn Monlu'],
    actingCareer: ['20 Once Again (2015)', 'Fighter of the Destiny (2017)', 'Sweet Combat (2018)', 'Shanghai Fortress (2019)', 'Medals of Honor (2021)'],
    modelingCareer: ['Various Chinese brands', 'Cartier Ambassador'],
    soloAlbums: ['Reloaded (2015)', 'Reloaded II (2016)', 'Venture (2017)', 'π-volume.1 (2020)'],
    awards: ['Solo music awards in China', 'Acting awards', 'Variety show awards'],
    socialMedia: {
      weibo: '@M鹿 M',
      instagram: '@7_luhan_m'
    },
    representativeColor: 'Telekinesis',
    funFacts: [
      'Known as the "Nation\'s First Love" in China',
      'Excellent at football',
      'Has a very gentle and cute personality',
      'Became hugely successful in China after leaving EXO',
      'Known for his deer-like features'
    ],
    family: ['Parents']
  },
  {
    id: '12',
    name: 'Tao',
    koreanName: '타오',
    birthDate: '1993-05-02',
    birthPlace: 'Qingdao, Shandong, China',
    position: ['Lead Rapper', 'Vocalist', 'Martial Artist'],
    nationality: 'Chinese',
    status: 'former',
    leftYear: 2015,

    height: '183 cm',
    weight: '68 kg',
    bloodType: 'AB',
    traineeYears: '2010-2012 (2 years)',
    debutDate: '2012-04-08',
    subUnits: ['EXO-M'],
    soloDebut: '2015',
    education: ['Qingdao No.2 Middle School'],
    languages: ['Mandarin', 'Korean'],
    instruments: ['Piano', 'Martial Arts'],
    hobbies: ['Wushu', 'Martial arts', 'Fashion'],
    nicknames: ['Panda', 'Huang Zitao', 'Peach'],
    actingCareer: ['You Are My Sunshine (2015)', 'Railroad Tigers (2016)', 'The Game Changer (2017)', 'Negotiator (2018)', 'Hot-Blooded Dance Crew (2020)'],
    modelingCareer: ['Various fashion brands', 'Street fashion influencer'],
    soloAlbums: ['TAO (2015)', 'The Road (2016)', 'Hello, Hello (2020)', 'IS GOINGON (2021)'],
    awards: ['Solo music awards', 'Martial arts achievements'],
    socialMedia: {
      weibo: '@黄子韬',
      instagram: '@hzt.tao'
    },
    representativeColor: 'Time Control',
    funFacts: [
      'Expert in Wushu and martial arts',
      'Known for his emotional and passionate personality',
      'Has unique fashion sense',
      'Very close to his father',
      'Often emotional and cries easily (in a endearing way)'
    ],
    family: ['Father (very close relationship)', 'Mother']
  }
];

const getInitials = (name: string) => {
  return name.split(' ').map(n => n[0]).join('').toUpperCase();
};

const calculateAge = (birthDate: string) => {
  const birth = new Date(birthDate);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
};

const getStatusColor = (status: Member['status']) => {
  switch (status) {
    case 'active': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    case 'solo': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    case 'hiatus': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    case 'former': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  }
};

const MemberDetailDialog = ({ member }: { member: Member }) => {
  return (
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <div className="flex items-center space-x-4">
          <Avatar className="h-20 w-20 border-2 border-primary/20">
            <AvatarImage src={member.avatar} alt={member.name} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold text-xl">
              {getInitials(member.name)}
            </AvatarFallback>
          </Avatar>
          <div>
            <DialogTitle className="text-2xl flex items-center gap-3">
              {member.name} <span className="text-lg text-muted-foreground">({member.koreanName})</span>
              <Badge className={getStatusColor(member.status)} variant="secondary">
                {member.status}
              </Badge>
            </DialogTitle>
            <DialogDescription className="text-base">
              {member.position.join(' • ')}
            </DialogDescription>
          </div>
        </div>
      </DialogHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><strong>Birth Date:</strong></div>
              <div>{member.birthDate} (Age {calculateAge(member.birthDate)})</div>
              <div><strong>Birth Place:</strong></div>
              <div>{member.birthPlace}</div>
              <div><strong>Nationality:</strong></div>
              <div>{member.nationality}</div>
              <div><strong>Height:</strong></div>
              <div>{member.height}</div>
              <div><strong>Weight:</strong></div>
              <div>{member.weight}</div>
              <div><strong>Blood Type:</strong></div>
              <div>{member.bloodType}</div>
              {member.representativeColor && (
                <>
                  <div><strong>Representative Color:</strong></div>
                  <div>{member.representativeColor}</div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Career Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Career Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><strong>Trainee Period:</strong></div>
              <div>{member.traineeYears}</div>
              <div><strong>EXO Debut:</strong></div>
              <div>{member.debutDate}</div>
              {member.soloDebut && (
                <>
                  <div><strong>Solo Debut:</strong></div>
                  <div>{member.soloDebut}</div>
                </>
              )}
              {member.leftYear && (
                <>
                  <div><strong>Left EXO:</strong></div>
                  <div className="text-red-600">{member.leftYear}</div>
                </>
              )}
            </div>
            <Separator />
            <div>
              <strong className="text-sm">Sub-units:</strong>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.subUnits.map((unit) => (
                  <Badge key={unit} variant="outline" className="text-xs">{unit}</Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Skills & Languages */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Skills & Languages</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <strong className="text-sm">Languages:</strong>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.languages.map((lang) => (
                  <Badge key={lang} variant="outline" className="text-xs">{lang}</Badge>
                ))}
              </div>
            </div>
            <div>
              <strong className="text-sm">Instruments:</strong>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.instruments.map((instrument) => (
                  <Badge key={instrument} variant="outline" className="text-xs">{instrument}</Badge>
                ))}
              </div>
            </div>
            <div>
              <strong className="text-sm">Hobbies:</strong>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.hobbies.map((hobby) => (
                  <Badge key={hobby} variant="secondary" className="text-xs">{hobby}</Badge>
                ))}
              </div>
            </div>
            <div>
              <strong className="text-sm">Nicknames:</strong>
              <div className="flex flex-wrap gap-1 mt-1">
                {member.nicknames.map((nickname) => (
                  <Badge key={nickname} variant="secondary" className="text-xs">{nickname}</Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Education & Family */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Education & Family</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <strong className="text-sm">Education:</strong>
              <ul className="text-sm mt-1 space-y-1">
                {member.education.map((school, index) => (
                  <li key={index} className="text-muted-foreground">• {school}</li>
                ))}
              </ul>
            </div>
            <Separator />
            <div>
              <strong className="text-sm">Family:</strong>
              <ul className="text-sm mt-1 space-y-1">
                {member.family.map((familyMember, index) => (
                  <li key={index} className="text-muted-foreground">• {familyMember}</li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Acting Career */}
        {member.actingCareer.length > 0 && (
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Acting Career</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-sm space-y-1">
                {member.actingCareer.map((work, index) => (
                  <li key={index} className="text-muted-foreground">• {work}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Solo Albums */}
        {member.soloAlbums.length > 0 && (
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Solo Albums</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {member.soloAlbums.map((album) => (
                  <Badge key={album} variant="outline">{album}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Fun Facts */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Fun Facts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-2">
              {member.funFacts.map((fact, index) => (
                <li key={index} className="text-muted-foreground">• {fact}</li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Social Media */}
        {Object.keys(member.socialMedia).length > 0 && (
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">Social Media</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {member.socialMedia.instagram && (
                  <Badge variant="outline">Instagram: {member.socialMedia.instagram}</Badge>
                )}
                {member.socialMedia.weibo && (
                  <Badge variant="outline">Weibo: {member.socialMedia.weibo}</Badge>
                )}
                {member.socialMedia.other && (
                  <Badge variant="outline">{member.socialMedia.other}</Badge>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DialogContent>
  );
};

export default function Index() {
  const [members, setMembers] = useState<Member[]>(initialMembers);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);



  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-accent/10">
      {/* Header */}
      <div className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Star className="h-8 w-8 text-primary fill-primary" />
                <div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                    EXO
                  </h1>
                  <p className="text-sm text-muted-foreground">Member Information System</p>
                </div>
              </div>
            </div>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Add Member
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-primary/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Members</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{members.length}</div>
              <p className="text-xs text-muted-foreground">Current roster</p>
            </CardContent>
          </Card>
          
          <Card className="border-green-200 dark:border-green-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Members</CardTitle>
              <Star className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {members.filter(m => m.status === 'active').length}
              </div>
              <p className="text-xs text-muted-foreground">Currently active</p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 dark:border-blue-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Solo Activities</CardTitle>
              <Music className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {members.filter(m => m.status === 'solo').length}
              </div>
              <p className="text-xs text-muted-foreground">Solo careers</p>
            </CardContent>
          </Card>

          <Card className="border-red-200 dark:border-red-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Former Members</CardTitle>
              <Users className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {members.filter(m => m.status === 'former').length}
              </div>
              <p className="text-xs text-muted-foreground">Left the group</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="all" className="space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <TabsList className="grid w-full grid-cols-4 lg:w-[500px]">
              <TabsTrigger value="all">All Members</TabsTrigger>
              <TabsTrigger value="current">Current</TabsTrigger>
              <TabsTrigger value="former">Former</TabsTrigger>
              <TabsTrigger value="detailed">Detailed</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.map((member) => (
                <Card key={member.id} className="group hover:shadow-lg transition-all duration-300 border-primary/10 hover:border-primary/30">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16 border-2 border-primary/20">
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback className="bg-primary/10 text-primary font-bold text-lg">
                          {getInitials(member.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <CardTitle className="text-lg group-hover:text-primary transition-colors">
                          {member.name}
                        </CardTitle>
                        <CardDescription className="text-sm font-medium">
                          {member.koreanName}
                        </CardDescription>
                        <Badge className={`mt-2 ${getStatusColor(member.status)}`} variant="secondary">
                          {member.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        Age {calculateAge(member.birthDate)}
                        {member.leftYear && (
                          <span className="ml-2 text-red-600">• Left {member.leftYear}</span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {member.position.map((pos) => (
                          <Badge key={pos} variant="outline" className="text-xs">
                            {pos}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-2">
                        <span className="text-xs text-muted-foreground">{member.nationality}</span>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="group-hover:bg-primary group-hover:text-primary-foreground">
                              <Edit className="h-3 w-3 mr-1" />
                              Details
                            </Button>
                          </DialogTrigger>
                          <MemberDetailDialog member={member} />
                        </Dialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="current" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.filter(member => member.status !== 'former').map((member) => (
                <Card key={member.id} className="group hover:shadow-lg transition-all duration-300 border-primary/10 hover:border-primary/30">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16 border-2 border-primary/20">
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback className="bg-primary/10 text-primary font-bold text-lg">
                          {getInitials(member.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <CardTitle className="text-lg group-hover:text-primary transition-colors">
                          {member.name}
                        </CardTitle>
                        <CardDescription className="text-sm font-medium">
                          {member.koreanName}
                        </CardDescription>
                        <Badge className={`mt-2 ${getStatusColor(member.status)}`} variant="secondary">
                          {member.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        Age {calculateAge(member.birthDate)}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {member.position.map((pos) => (
                          <Badge key={pos} variant="outline" className="text-xs">
                            {pos}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-2">
                        <span className="text-xs text-muted-foreground">{member.nationality}</span>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="group-hover:bg-primary group-hover:text-primary-foreground">
                              <Edit className="h-3 w-3 mr-1" />
                              Details
                            </Button>
                          </DialogTrigger>
                          <MemberDetailDialog member={member} />
                        </Dialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="former" className="space-y-6">
            <div className="mb-4 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-sm text-red-800 dark:text-red-200">
                Former members who left EXO to pursue solo careers or due to other circumstances.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.filter(member => member.status === 'former').map((member) => (
                <Card key={member.id} className="group hover:shadow-lg transition-all duration-300 border-red-200 dark:border-red-800">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16 border-2 border-red-200 dark:border-red-800">
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 font-bold text-lg">
                          {getInitials(member.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <CardTitle className="text-lg">
                          {member.name}
                        </CardTitle>
                        <CardDescription className="text-sm font-medium">
                          {member.koreanName}
                        </CardDescription>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge className={getStatusColor(member.status)} variant="secondary">
                            {member.status}
                          </Badge>
                          {member.leftYear && (
                            <Badge variant="outline" className="text-xs text-red-600 border-red-300">
                              Left {member.leftYear}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2" />
                        Age {calculateAge(member.birthDate)}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {member.position.map((pos) => (
                          <Badge key={pos} variant="outline" className="text-xs">
                            {pos}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex justify-between items-center pt-2">
                        <span className="text-xs text-muted-foreground">{member.nationality}</span>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="ghost">
                              <Edit className="h-3 w-3 mr-1" />
                              Details
                            </Button>
                          </DialogTrigger>
                          <MemberDetailDialog member={member} />
                        </Dialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="detailed" className="space-y-4">
            <div className="space-y-4">
              {members.map((member) => (
                <Card key={member.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-6">
                        <Avatar className="h-20 w-20 border-2 border-primary/20">
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback className="bg-primary/10 text-primary font-bold text-xl">
                            {getInitials(member.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-3">
                            <h3 className="text-xl font-bold">{member.name}</h3>
                            <span className="text-lg text-muted-foreground">{member.koreanName}</span>
                            <Badge className={getStatusColor(member.status)} variant="secondary">
                              {member.status}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span>{member.nationality}</span>
                            <span>•</span>
                            <span>Born {member.birthDate}</span>
                            <span>•</span>
                            <span>Age {calculateAge(member.birthDate)}</span>
                            {member.leftYear && (
                              <>
                                <span>•</span>
                                <span className="text-red-600">Left {member.leftYear}</span>
                              </>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {member.position.map((pos) => (
                              <Badge key={pos} variant="outline">
                                {pos}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">
                            <Edit className="h-4 w-4 mr-2" />
                            View Details
                          </Button>
                        </DialogTrigger>
                        <MemberDetailDialog member={member} />
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
